﻿namespace Geneezy.Common.Helpers.Class
{
    public static class GlobalMessage
    {
        public static string RegisterNotFound = "Registro não encontrado.";
        public static string RegisterSuccessfullyDeleted = "Registro excluído com sucesso.";
    }
}
