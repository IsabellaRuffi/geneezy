﻿namespace Geneezy.Common.Helpers.Class
{
    public class SelectItemStructure<T>
    {
        public string Label { get; set; }
        public uint Value { get; set; }
    }
}
