export class Person{
    public id?: number;
    public name?: string;
    public lastName?: string;
    public cpf?: number;
    public dateOfBirth?: string;
    public dateOfRegister?: string;
    public isActive?: boolean;
    public telephone?: number;
    public mail?: string;
    public sex?: string;
    public observation?: string;
    public supplierId?: number;
}