export interface SelectItemStructure{
    label?: string;
    value?: number;
}