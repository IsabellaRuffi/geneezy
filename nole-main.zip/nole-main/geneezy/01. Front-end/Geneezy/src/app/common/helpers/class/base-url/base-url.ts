export abstract class BaseUrl {
    public static baseUrl: string = 'http://localhost:5000/api/v1';
}